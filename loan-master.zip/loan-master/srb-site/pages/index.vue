<template>
  <main>
    <div>
      <a target="_blank" href="/">
        <img src="~/assets/images/banner.jpg" />
      </a>
    </div>
    <div class="new-announcement">
      <div class="new-announcement-title">最新公告</div>
      <div class="new-announcement-content">
        <div id="scrollDiv">
          <ul style="margin-top: 0px;">
            <li>
              <a class="black-link" href="公司公告详细.html" target="_blank">
                2020年9月8日还款公告
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="ipubs">
      <span class="o1">累计投资金额:<strong>1,047,288,128.79</strong>元</span>
      <span class="o1">累计注册人数:<strong>20649</strong>人</span>
    </div>
    <div class="feature">
      <a class="fea1" href="#">
        <i></i>
        <h3>高收益</h3>
        <span>
          年化收益率最高达“20%<br />
          50元起投，助您轻松获收益
        </span>
      </a>
      <a class="fea2" href="#">
        <i></i>
        <h3>安全理财</h3>
        <span>
          100%本息保障<br />
          实物质押，多重风控审核
        </span>
      </a>
      <a class="fea3" href="#">
        <i></i>
        <h3>随时赎回</h3>
        <span>
          两步赎回您的资金<br />
          最快当日到账
        </span>
      </a>
      <a class="fea4" href="#">
        <i></i>
        <h3>随时随地理财</h3>
        <span>
          下载手机客户端<br />
          随时随地轻松理财
        </span>
      </a>
    </div>
  </main>
</template>

<script>
import '~/assets/css/index.css'

export default {}
</script>
