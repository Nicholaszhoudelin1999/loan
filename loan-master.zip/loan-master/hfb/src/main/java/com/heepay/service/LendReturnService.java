package com.heepay.service;

import java.util.Map;

;

public interface LendReturnService {


	Map<String, Object> returnCommit(Map<String, Object> paramMap);

}
