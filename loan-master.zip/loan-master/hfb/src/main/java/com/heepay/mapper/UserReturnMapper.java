package com.heepay.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.heepay.model.UserReturn;
import org.springframework.stereotype.Repository;

@Repository
public interface UserReturnMapper extends BaseMapper<UserReturn> {

}
