package com.heepay.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.heepay.model.UserAccount;
import org.springframework.stereotype.Repository;

@Repository
public interface UserAccountMapper extends BaseMapper<UserAccount> {

}
